function onOff(){
    document
    .querySelector("#modal")
    .classList
    .toggle("hide")
}